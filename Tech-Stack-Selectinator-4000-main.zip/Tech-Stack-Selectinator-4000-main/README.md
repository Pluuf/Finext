# Tech-Stack-Selectinator-4000
 De CFO Tech Stack selectie app
